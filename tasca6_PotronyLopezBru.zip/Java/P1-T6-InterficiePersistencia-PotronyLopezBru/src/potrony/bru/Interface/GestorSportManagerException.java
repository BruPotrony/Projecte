/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package potrony.bru.Interface;

/**
 *
 * @author Vago
 */
public class GestorSportManagerException extends Exception {

    public GestorSportManagerException(String message) {
        super(message);
    }

    public GestorSportManagerException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
